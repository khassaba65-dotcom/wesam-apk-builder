const pages = [...document.querySelectorAll('.page')];
const navItems = [...document.querySelectorAll('.nav-item')];
const toolButtons = [...document.querySelectorAll('[data-tool]')];
const allToolsGrid = document.querySelector('.all-tools-grid');
const toast = document.getElementById('toast');
const modalBackdrop = document.getElementById('modalBackdrop');
let toastTimer;

const toolNames = {
  colors: 'مولّد الألوان',
  timer: 'المؤقت البسيط',
  notes: 'الملاحظات',
  calculator: 'الآلة الحاسبة'
};

function showPage(pageName) {
  pages.forEach(page => page.classList.toggle('active', page.dataset.page === pageName));
  navItems.forEach(item => item.classList.toggle('active', item.dataset.pageTarget === pageName));
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

document.querySelectorAll('[data-page-target]').forEach(button => {
  button.addEventListener('click', () => showPage(button.dataset.pageTarget));
});

function notify(message) {
  toast.textContent = message;
  toast.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove('show'), 2400);
}

function openTool(tool) {
  notify(`${toolNames[tool]} — واجهة تجريبية جاهزة للتطوير`);
}

toolButtons.forEach(button => button.addEventListener('click', () => openTool(button.dataset.tool)));

// Create a second, complete tools view from the same tool definitions.
if (allToolsGrid) {
  const cards = toolButtons.map(button => button.cloneNode(true));
  cards.forEach(card => {
    card.addEventListener('click', () => openTool(card.dataset.tool));
    allToolsGrid.appendChild(card);
  });
}

function setModal(open) {
  modalBackdrop.classList.toggle('open', open);
  modalBackdrop.setAttribute('aria-hidden', String(!open));
  if (open) document.getElementById('modalClose').focus();
}

document.getElementById('settingsBtn').addEventListener('click', () => setModal(true));
document.getElementById('modalClose').addEventListener('click', () => setModal(false));
document.getElementById('modalDone').addEventListener('click', () => {
  setModal(false);
  notify('تم تحديث تفضيلات الواجهة');
});
modalBackdrop.addEventListener('click', event => {
  if (event.target === modalBackdrop) setModal(false);
});
document.addEventListener('keydown', event => {
  if (event.key === 'Escape') setModal(false);
});

document.getElementById('quietToggle').addEventListener('change', event => {
  document.body.classList.toggle('quiet', event.target.checked);
  notify(event.target.checked ? 'تم تفعيل الوضع الهادئ' : 'تم إيقاف الوضع الهادئ');
});

// Subtle touch feedback that feels natural on mobile.
document.querySelectorAll('button').forEach(button => {
  button.addEventListener('touchstart', () => button.classList.add('pressed'), { passive: true });
  button.addEventListener('touchend', () => button.classList.remove('pressed'), { passive: true });
});
